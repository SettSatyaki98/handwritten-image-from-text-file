from PIL import Image, ImageDraw
import os
 
# name of the file to save
filename = "white.jpg"
 
# create new image
image = Image.new(mode = "RGB", size = (1654,2338), color = "white")
 
# save the file
image.save(filename)
 
